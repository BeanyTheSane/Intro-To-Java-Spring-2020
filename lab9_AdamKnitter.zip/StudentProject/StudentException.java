public class StudentException extends
				Exception{
                    
    private static final long serialVersionUID = 1L;

    public StudentException(String arg) {
		super(arg);
	}
}