public class CourseException extends
				Exception{
                    
    private static final long serialVersionUID = 1L;

    public CourseException(String arg) {
		super(arg);
	}
}