public class lab7 {

    public static void main(final String[] args) {
        Test test = new Test();

        test.runAllQuick();
    }
}