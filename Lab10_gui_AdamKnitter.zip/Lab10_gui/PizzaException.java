
public class PizzaException extends
Exception {
    private static final long serialVersionUID = 1L;

    public PizzaException(String arg) {
		super(arg);
	}
}